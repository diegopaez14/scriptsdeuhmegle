function exportarTextoComoJPGSTC() {
    let divSTC = document.getElementsByClassName("chatWindow")[0];

    if (!divSTC) {
        console.error("No se encontró el chat.");
        return;
    }

    let prevOverflowSTC = divSTC.style.overflow;
    let prevHeightSTC = divSTC.style.height;

    divSTC.style.overflow = "visible";
    divSTC.style.height = divSTC.scrollHeight + "px";

    convertirChatAImagenSTC(divSTC, prevOverflowSTC, prevHeightSTC);
}

function convertirChatAImagenSTC(divSTC, prevOverflowSTC, prevHeightSTC) {
    html2canvas(divSTC, {
        backgroundColor: "#fff",
        useCORS: true,
        scrollX: 0,
        scrollY: 0,
        windowWidth: divSTC.scrollWidth,
        windowHeight: divSTC.scrollHeight,
        scale: 2
    }).then(canvasSTC => {
        divSTC.style.overflow = prevOverflowSTC;
        divSTC.style.height = prevHeightSTC;

        const ahora = new Date();
        const nombre = `uhmeglechat_${ahora.getFullYear()}${String(ahora.getMonth()+1).padStart(2,'0')}${String(ahora.getDate()).padStart(2,'0')}${String(ahora.getHours()).padStart(2,'0')}${String(ahora.getMinutes()).padStart(2,'0')}${String(ahora.getSeconds()).padStart(2,'0')}.jpg`;

        const enlace = document.createElement("a");
        enlace.href = canvasSTC.toDataURL("image/jpeg", 0.9);
        enlace.download = nombre;
        enlace.click();
    });
}
